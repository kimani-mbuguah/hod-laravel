<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Devotions extends Model
{
    //
}
