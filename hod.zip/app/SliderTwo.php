<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderTwo extends Model
{
    //
}
