<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderOne extends Model
{
    //
}
