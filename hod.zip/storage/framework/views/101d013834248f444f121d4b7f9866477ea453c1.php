<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Gallery</a></li>
                    <li class="active">Add Image</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">

        <div class="row">

            <div class="col-xs-12 col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong>Upload New Image</strong>
                    </div>
                    <div class="card-body card-block">
                        <?php echo Form::open(['action' => 'GalleryController@store','files' => true,'method' => 'POST']); ?>

                            <div class="form-group">
                                <?php echo e(Form::label('new image', 'New Image', ['class' => 'form-control-label'])); ?>

                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user"></i></div>
                                    <?php echo e(Form::file('image')); ?>

                                </div>
                                <small class="form-text text-muted">ex. hod.jpg</small>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('image description', 'Image Description', ['class' => 'form-control-label'])); ?>

                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-group"></i></div>
                                    <?php echo e(Form::textarea('description', '', ['id' => 'article-ckeditor','class' => 'form-control', 'placeholder'=>'Image Description'])); ?>

                                </div>
                                <small class="form-text text-muted">ex. Youth Connect</small>
                            </div>
                            <div class="fom-group">
                                <?php echo e(Form::submit('Upload Image',['class'=>'btn btn-outline-primary btn-lg btn-block'])); ?>

                            </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
</div><!-- .content -->   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>