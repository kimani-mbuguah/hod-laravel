<?php $__env->startSection('content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <?php if(count($sermons) >0 ): ?>
                <?php $__currentLoopData = $sermons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sermon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <section class="card">
                    <div class="twt-feed blue-bg">
                        <div class="media">
                            <div class="media-body">
                                <h2 class="text-white display-6"><?php echo e($sermon->title); ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="twt-write col-sm-12">
                        <p><?php echo str_limit($sermon->description, $limit = 100, $end = '...'); ?></p>
                    </div>
                    <footer class="twt-footer">
                        <span class="pull-left">
                            <button class="btn btn-warning"><a href="/word/<?php echo e($sermon->id); ?>/edit">Edit Sermon</a></button>
                        </span>
                        <span class="pull-right">
                            <?php echo Form::open(['action' => ['SermonsController@destroy',$sermon->id],'method' => 'POST']); ?>

                            <?php echo e(Form::hidden('_method','DELETE')); ?>

                            <?php echo e(Form::submit('Delete Sermon',['class'=>'btn btn-danger'])); ?>

                        </span>
                    </footer>
                </section>
            </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                <?php echo e($sermons->links()); ?> 
            <?php else: ?>
                <h3>No posts available</h3>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>