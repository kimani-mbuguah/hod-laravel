<?php $__env->startSection('content'); ?>
<div class="page-top">
        <div class="parallax" style="background:url(images/parallax1.jpg);"></div>	
        <div class="container"> 
            <h1>HoD <span>GALLERY</span></h1>
            <ul>
                <li><a href="/" title="">Home</a></li>
                <li><a href="#" title="">House of Destiny Church Gallery</a></li>
            </ul>
        </div>
    </div><!--- PAGE TOP -->
    <section>
        <div class="block">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="remove-ext">
                            <div class="row">
                                <div class="mas-gallery">
                                    <?php if(count($galleries) >0 ): ?>
                                    <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="gallery lightbox">
                                            <img src="/images/gallery/<?php echo e($gallery->image); ?>" alt="<?php echo e($gallery->description); ?>" /> 
                                            <div class="gallery-title">
                                                <i class="fa fa-picture-o"></i>
                                                <h3><?php echo $gallery->description; ?></h3>
                                            </div>
                                            <ul>
                                                <li><a  href="/images/gallery/<?php echo e($gallery->image); ?>" title="<?php echo e($gallery->desctiption); ?>"><img src="images/resource/gallery-thumb1.jpg" alt="<?php echo e($gallery->description); ?>" /></a></li>
                                            </ul>
                                        </div><!-- GALLERY ITEM -->
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    <?php echo e($galleries->links()); ?> 
                                    <?php else: ?>
                                        <h3>No photos available</h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>